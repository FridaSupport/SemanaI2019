# -*- coding: utf-8 -*-
"""
Created on Fri Oct 25 11:17:11 2019

@author: A01169319
"""

import os
import pandas as pd


file = pd.read_csv("CSV/train.csv")


def checkMaxMin(width, height, xmin, ymin, xmax, ymax):
    
    if xmax > width:
        return True
    if ymax > height:
        return True
    
    return False
    

files = file.apply(lambda row: checkMaxMin(row["width"],
                                           row["height"],
                                           row["xmin"],
                                           row["ymin"],
                                           row["xmax"],
                                           row["ymax"]), axis=1)

file[files]
